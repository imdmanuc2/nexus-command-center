"""Declarative enterprise playbook framework."""
