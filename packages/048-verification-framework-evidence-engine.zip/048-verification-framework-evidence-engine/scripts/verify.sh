#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../../.." && pwd)"
cd "$ROOT"
set -a; source backend/data/private/cmdb.env; set +a
export PGPASSWORD="$NEXUS_DB_PASSWORD"
PSQL=(psql -q -At -v ON_ERROR_STOP=1 -h "$NEXUS_DB_HOST" -p "$NEXUS_DB_PORT" -U "$NEXUS_DB_USER" -d "$NEXUS_DB_NAME")
for table in verification_profiles verification_profile_steps verification_runs \
 verification_step_runs verification_evidence verification_events; do
 "${PSQL[@]}" -c "SELECT to_regclass('nexus.$table') IS NOT NULL;" | grep -qx t
done
echo "verification schema PASS"
venv/bin/python -m py_compile backend/db/repositories/verification_repository.py \
 backend/services/verification_service.py backend/jobs/verification_worker.py \
 backend/modules/platform_verifications.py backend/api/install_verification_routes.py
echo "Python compilation PASS"
sudo systemctl is-active --quiet nexus-verification-worker.service
echo "verification worker service PASS"
curl -fsS http://127.0.0.1:8080/api/verifications/profiles | \
 venv/bin/python -c "import json,sys; assert isinstance(json.load(sys.stdin)['profiles'],list)"
curl -fsS "http://127.0.0.1:8080/api/verifications/runs?limit=1" | \
 venv/bin/python -c "import json,sys; assert isinstance(json.load(sys.stdin)['runs'],list)"
echo "verification APIs PASS"
RUN_ID="$(curl -fsS -X POST http://127.0.0.1:8080/api/verifications/run \
 -H 'Content-Type: application/json' -d '{
 "profileKey":"nexus.local.identity","targetType":"asset","targetId":"nexus-local",
 "assetId":"nexus-local","transport":"local","parameters":{},
 "requestedBy":"package-048-verification"}' | \
 venv/bin/python -c "import json,sys; print(json.load(sys.stdin)['run_id'])")"
cleanup(){ "${PSQL[@]}" -c "DELETE FROM nexus.verification_runs WHERE run_id='$RUN_ID'::uuid;" >/dev/null || true; }
trap cleanup EXIT
for _ in $(seq 1 40); do
 STATUS="$("${PSQL[@]}" -c "SELECT status FROM nexus.verification_runs WHERE run_id='$RUN_ID'::uuid;")"
 [[ "$STATUS" == "passed" ]] && break
 [[ "$STATUS" == "failed" ]] && { curl -fsS "http://127.0.0.1:8080/api/verifications/runs/$RUN_ID"; exit 1; }
 sleep 1
done
"${PSQL[@]}" -c "SELECT status='passed' AND result='passed' AND score=100 AND completed_at IS NOT NULL
 FROM nexus.verification_runs WHERE run_id='$RUN_ID'::uuid;" | grep -qx t
"${PSQL[@]}" -c "SELECT COUNT(*)=1 FROM nexus.verification_step_runs
 WHERE run_id='$RUN_ID'::uuid AND status='passed';" | grep -qx t
"${PSQL[@]}" -c "SELECT COUNT(*)>=1 FROM nexus.verification_evidence
 WHERE run_id='$RUN_ID'::uuid;" | grep -qx t
"${PSQL[@]}" -c "SELECT COUNT(*)>=2 FROM nexus.verification_events
 WHERE run_id='$RUN_ID'::uuid;" | grep -qx t
echo "verification lifecycle PASS"
echo "Package 048 verification PASS"
