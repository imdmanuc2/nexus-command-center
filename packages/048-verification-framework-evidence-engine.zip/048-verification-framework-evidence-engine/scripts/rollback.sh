#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../../.." && pwd)"
cd "$ROOT"
sudo systemctl disable --now nexus-verification-worker.service 2>/dev/null || true
sudo rm -f /etc/systemd/system/nexus-verification-worker.service
sudo systemctl daemon-reload
set -a; source backend/data/private/cmdb.env; set +a
export PGPASSWORD="$NEXUS_DB_PASSWORD"
psql -v ON_ERROR_STOP=1 -h "$NEXUS_DB_HOST" -p "$NEXUS_DB_PORT" \
 -U "$NEXUS_DB_USER" -d "$NEXUS_DB_NAME" <<'SQL'
BEGIN;
DROP TABLE IF EXISTS nexus.verification_events;
DROP TABLE IF EXISTS nexus.verification_evidence;
DROP TABLE IF EXISTS nexus.verification_step_runs;
DROP TABLE IF EXISTS nexus.verification_runs;
DROP TABLE IF EXISTS nexus.verification_profile_steps;
DROP TABLE IF EXISTS nexus.verification_profiles;
COMMIT;
SQL
echo "Package 048 rollback complete. Restore patched files from the package backup if needed."
