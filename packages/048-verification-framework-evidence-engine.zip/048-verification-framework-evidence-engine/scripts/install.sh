#!/usr/bin/env bash
set -euo pipefail
PKG="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
ROOT="$(cd "$PKG/../.." && pwd)"
cd "$ROOT"
BACKUP="$ROOT/backend/data/private/package-backups/048-verification-framework-evidence-engine-$(date +%Y%m%d-%H%M%S)"
mkdir -p "$BACKUP"
for path in backend/db/repositories/verification_repository.py backend/services/verification_service.py \
 backend/jobs/verification_worker.py backend/modules/platform_verifications.py \
 backend/api/install_verification_routes.py backend/api/server.py; do
 if [[ -f "$path" ]]; then mkdir -p "$BACKUP/$(dirname "$path")"; cp -a "$path" "$BACKUP/$path"; fi
done
for path in \
 backend/db/migrations/037_verification_framework_evidence_engine.sql \
 backend/db/repositories/verification_repository.py \
 backend/services/verification_service.py backend/jobs/verification_worker.py \
 backend/modules/platform_verifications.py backend/api/install_verification_routes.py; do
 install -D -m 0644 "$PKG/$path" "$ROOT/$path"
done
set -a; source backend/data/private/cmdb.env; set +a
export PGPASSWORD="$NEXUS_DB_PASSWORD"
psql -v ON_ERROR_STOP=1 -h "$NEXUS_DB_HOST" -p "$NEXUS_DB_PORT" \
 -U "$NEXUS_DB_USER" -d "$NEXUS_DB_NAME" \
 -f backend/db/migrations/037_verification_framework_evidence_engine.sql
venv/bin/python - <<'PY'
from pathlib import Path
p=Path("backend/api/server.py")
text=p.read_text()
if "install_verification_routes" not in text:
    lines=text.splitlines(keepends=True)
    insert=0
    for i,line in enumerate(lines):
        if line.startswith("from ") or line.startswith("import "): insert=i+1
    lines.insert(insert,"from backend.api.install_verification_routes import install as install_verification_routes\n")
    text="".join(lines)
    marker=None
    for candidate in ("app = FastAPI(","app=FastAPI("):
        pos=text.find(candidate)
        if pos>=0: marker=pos; break
    if marker is None: raise SystemExit("Could not locate FastAPI app creation")
    end=text.find("\n",marker)
    text=text[:end+1]+"\ninstall_verification_routes(app)\n"+text[end+1:]
    p.write_text(text)
PY
sudo install -m 0644 "$PKG/systemd/nexus-verification-worker.service" \
 /etc/systemd/system/nexus-verification-worker.service
sudo systemctl daemon-reload
sudo systemctl enable --now nexus-verification-worker.service
sudo systemctl restart nexus-api.service
echo "Package 048 install PASS"
