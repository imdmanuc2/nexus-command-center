# Package 048 — Verification Framework & Evidence Engine

Reusable, database-backed verification for Nexus operations.

## Includes

- Verification profiles and ordered steps
- Durable queued runs and lease-based worker
- Step evidence and immutable events
- Capability, TCP, HTTP, file and regex verifiers
- Change-request pass/fail integration
- Rollback recommendations
- Stale lease recovery
- REST API, systemd service, doctor/install/verify/rollback scripts

Run `scripts/doctor.sh`, `scripts/install.sh`, then `scripts/verify.sh`.
Commit only after verification passes.
