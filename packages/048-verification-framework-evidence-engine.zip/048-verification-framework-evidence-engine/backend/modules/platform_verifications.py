from fastapi import APIRouter,HTTPException,Query
from backend.db.repositories import verification_repository as repo
router=APIRouter(prefix="/api/verifications",tags=["verifications"])
@router.get("/profiles")
def list_profiles(): return {"profiles":repo.profiles()}
@router.post("/profiles")
def create_profile(payload:dict):
    try: return repo.create_profile(payload)
    except Exception as exc: raise HTTPException(400,str(exc)) from exc
@router.get("/runs")
def list_runs(limit:int=Query(100,ge=1,le=500)): return {"runs":repo.runs(limit)}
@router.get("/runs/{run_id}")
def get_run(run_id:str):
    value=repo.get(run_id)
    if value is None: raise HTTPException(404,"Verification run not found")
    return value
@router.post("/run")
def queue_run(payload:dict):
    try: return repo.queue(payload)
    except Exception as exc: raise HTTPException(400,str(exc)) from exc
@router.post("/runs/{run_id}/retry")
def retry(run_id:str):
    current=repo.get(run_id)
    if current is None: raise HTTPException(404,"Verification run not found")
    return repo.queue({"profileKey":current["profile_key"],"changeId":current.get("change_id"),
      "rollbackId":current.get("rollback_id"),"targetType":current["target_type"],
      "targetId":current["target_id"],"assetId":current.get("asset_id"),
      "transport":current["transport"],"parameters":current.get("parameters") or {},
      "context":{"retryOf":run_id,**(current.get("context") or {})},
      "requestedBy":"verification-retry"})
