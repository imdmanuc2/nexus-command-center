# Changelog

## 1.0.0
- Added reusable verification profiles, runs, steps, evidence and events.
- Added typed verifier worker and stale lease recovery.
- Added API and change-management integration.
