#!/usr/bin/env bash
set -euo pipefail
PKG_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
ROOT="$(cd "$PKG_DIR/../.." && pwd)"
for f in \
  backend/api/server.py \
  backend/db/migrations/004_operations_queue.sql \
  backend/db/migrations/019_managed_host_capabilities.sql \
  backend/services/service_impact_service.py \
  backend/services/service_maintenance_service.py \
  frontend/service-operations.html \
  backend/data/private/cmdb.env
do test -f "$ROOT/$f"; done
command -v psql >/dev/null
command -v python3 >/dev/null
command -v curl >/dev/null
echo "Package 045 doctor PASS"
