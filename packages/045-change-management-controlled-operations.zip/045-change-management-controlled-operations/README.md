# Package 045 — Change Management & Controlled Operations

Package 045 introduces the Nexus controlled-change lifecycle and connects approved changes to the existing shared Operations Engine queue.

## Included

- Change templates
- Change requests
- Approval history
- Execution steps and immutable execution log
- Dependency impact snapshots
- Maintenance-window enforcement
- Approval, execute, complete, fail, cancel, and rollback APIs
- Queue handoff to `nexus.operation_queue`
- Operations Center change-management UI
- Strict live endpoint verification

## Safety boundary

This package never runs arbitrary shell commands from the browser. Execution is handed to the existing allow-listed capability and Operations Engine infrastructure. Creating or approving a change does not bypass capability validation.
