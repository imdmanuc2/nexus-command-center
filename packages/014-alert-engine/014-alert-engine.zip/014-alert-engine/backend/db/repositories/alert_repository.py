from __future__ import annotations

from typing import Any
from psycopg.types.json import Jsonb

from backend.db.connection import get_connection, transaction


def list_enabled_rules() -> list[dict[str, Any]]:
    with get_connection() as connection:
        with connection.cursor() as cursor:
            cursor.execute(
                """
                SELECT *
                FROM nexus.alert_rules
                WHERE enabled = TRUE
                ORDER BY rule_id
                """
            )
            return cursor.fetchall()


def get_alert_engine_state() -> dict[str, Any]:
    with get_connection() as connection:
        with connection.cursor() as cursor:
            cursor.execute(
                """
                SELECT *
                FROM nexus.alert_engine_state
                WHERE engine_name = 'platform-alert-engine'
                """
            )
            row = cursor.fetchone()

    return row or {"last_event_id": 0}


def list_events_after(event_id: int) -> list[dict[str, Any]]:
    with get_connection() as connection:
        with connection.cursor() as cursor:
            cursor.execute(
                """
                SELECT *
                FROM nexus.platform_events
                WHERE event_id > %s
                ORDER BY event_id
                """,
                (event_id,),
            )
            return cursor.fetchall()


def open_or_update_alert(
    *,
    rule_id: str,
    event_id: int,
    entity_type: str,
    entity_id: str,
    severity: str,
    title: str,
    message: str,
    metadata: dict[str, Any] | None = None,
) -> str:
    with transaction() as connection:
        with connection.cursor() as cursor:
            cursor.execute(
                """
                SELECT alert_id
                FROM nexus.alerts
                WHERE rule_id = %s
                  AND entity_type = %s
                  AND entity_id = %s
                  AND status IN ('open', 'acknowledged')
                FOR UPDATE
                """,
                (rule_id, entity_type, entity_id),
            )
            existing = cursor.fetchone()

            if existing:
                cursor.execute(
                    """
                    UPDATE nexus.alerts
                    SET
                        event_id = %s,
                        severity = %s,
                        title = %s,
                        message = %s,
                        last_triggered_at = NOW(),
                        trigger_count = trigger_count + 1,
                        metadata = %s,
                        updated_at = NOW()
                    WHERE alert_id = %s
                    """,
                    (
                        event_id,
                        severity,
                        title,
                        message,
                        Jsonb(metadata or {}),
                        existing["alert_id"],
                    ),
                )
                return "updated"

            cursor.execute(
                """
                INSERT INTO nexus.alerts (
                    rule_id,
                    entity_type,
                    entity_id,
                    event_id,
                    status,
                    severity,
                    title,
                    message,
                    metadata
                )
                VALUES (
                    %s, %s, %s, %s,
                    'open', %s, %s, %s, %s
                )
                """,
                (
                    rule_id,
                    entity_type,
                    entity_id,
                    event_id,
                    severity,
                    title,
                    message,
                    Jsonb(metadata or {}),
                ),
            )
            return "opened"


def resolve_alerts_for_entity(
    *,
    entity_type: str,
    entity_id: str,
) -> int:
    with transaction() as connection:
        with connection.cursor() as cursor:
            cursor.execute(
                """
                UPDATE nexus.alerts
                SET
                    status = 'resolved',
                    resolved_at = NOW(),
                    updated_at = NOW()
                WHERE entity_type = %s
                  AND entity_id = %s
                  AND status IN ('open', 'acknowledged')
                """,
                (entity_type, entity_id),
            )
            return cursor.rowcount


def update_alert_engine_state(
    *,
    last_event_id: int,
    status: str,
    evaluated_events: int,
    alerts_opened: int,
    alerts_updated: int,
    alerts_resolved: int,
    error: str = "",
) -> None:
    with transaction() as connection:
        with connection.cursor() as cursor:
            cursor.execute(
                """
                INSERT INTO nexus.alert_engine_state (
                    engine_name,
                    last_event_id,
                    last_started_at,
                    last_completed_at,
                    last_status,
                    last_error,
                    evaluated_events,
                    alerts_opened,
                    alerts_updated,
                    alerts_resolved,
                    updated_at
                )
                VALUES (
                    'platform-alert-engine',
                    %s,
                    NOW(),
                    NOW(),
                    %s,
                    %s,
                    %s,
                    %s,
                    %s,
                    %s,
                    NOW()
                )
                ON CONFLICT (engine_name)
                DO UPDATE SET
                    last_event_id = EXCLUDED.last_event_id,
                    last_started_at = NOW(),
                    last_completed_at = NOW(),
                    last_status = EXCLUDED.last_status,
                    last_error = EXCLUDED.last_error,
                    evaluated_events = EXCLUDED.evaluated_events,
                    alerts_opened = EXCLUDED.alerts_opened,
                    alerts_updated = EXCLUDED.alerts_updated,
                    alerts_resolved = EXCLUDED.alerts_resolved,
                    updated_at = NOW()
                """,
                (
                    last_event_id,
                    status,
                    error,
                    evaluated_events,
                    alerts_opened,
                    alerts_updated,
                    alerts_resolved,
                ),
            )


def list_alerts(limit: int = 100) -> list[dict[str, Any]]:
    with get_connection() as connection:
        with connection.cursor() as cursor:
            cursor.execute(
                """
                SELECT *
                FROM nexus.alerts
                ORDER BY
                    CASE status
                        WHEN 'open' THEN 1
                        WHEN 'acknowledged' THEN 2
                        ELSE 3
                    END,
                    last_triggered_at DESC
                LIMIT %s
                """,
                (max(1, min(limit, 1000)),),
            )
            rows = cursor.fetchall()

    return [
        {
            "alertId": row["alert_id"],
            "ruleId": row["rule_id"],
            "entityType": row["entity_type"],
            "entityId": row["entity_id"],
            "eventId": row["event_id"],
            "status": row["status"],
            "severity": row["severity"],
            "title": row["title"],
            "message": row["message"],
            "firstTriggeredAt": row["first_triggered_at"].isoformat(),
            "lastTriggeredAt": row["last_triggered_at"].isoformat(),
            "resolvedAt": (
                row["resolved_at"].isoformat()
                if row["resolved_at"] else None
            ),
            "triggerCount": row["trigger_count"],
            "metadata": row["metadata"] or {},
        }
        for row in rows
    ]


def alert_summary() -> dict[str, Any]:
    with get_connection() as connection:
        with connection.cursor() as cursor:
            cursor.execute(
                """
                SELECT
                    COUNT(*) FILTER (
                        WHERE status IN ('open', 'acknowledged')
                    ) AS active_count,
                    COUNT(*) FILTER (
                        WHERE status = 'open'
                          AND severity = 'critical'
                    ) AS critical_count,
                    COUNT(*) FILTER (
                        WHERE status = 'open'
                          AND severity = 'warning'
                    ) AS warning_count,
                    COUNT(*) FILTER (
                        WHERE status = 'resolved'
                    ) AS resolved_count
                FROM nexus.alerts
                """
            )
            row = cursor.fetchone()

    return {
        "activeCount": row["active_count"],
        "criticalCount": row["critical_count"],
        "warningCount": row["warning_count"],
        "resolvedCount": row["resolved_count"],
    }
