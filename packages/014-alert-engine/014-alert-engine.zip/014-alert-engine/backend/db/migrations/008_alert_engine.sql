BEGIN;

CREATE SCHEMA IF NOT EXISTS nexus;

CREATE TABLE IF NOT EXISTS nexus.alert_rules (
    rule_id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    description TEXT NOT NULL DEFAULT '',
    entity_type TEXT NOT NULL DEFAULT '*',
    event_type TEXT NOT NULL,
    minimum_severity TEXT NOT NULL DEFAULT 'warning',
    enabled BOOLEAN NOT NULL DEFAULT TRUE,
    auto_resolve BOOLEAN NOT NULL DEFAULT TRUE,
    cooldown_seconds INTEGER NOT NULL DEFAULT 300,
    metadata JSONB NOT NULL DEFAULT '{}'::JSONB,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS nexus.alerts (
    alert_id BIGSERIAL PRIMARY KEY,
    rule_id TEXT NOT NULL REFERENCES nexus.alert_rules(rule_id),
    entity_type TEXT NOT NULL,
    entity_id TEXT NOT NULL,
    event_id BIGINT REFERENCES nexus.platform_events(event_id),
    status TEXT NOT NULL DEFAULT 'open',
    severity TEXT NOT NULL,
    title TEXT NOT NULL,
    message TEXT NOT NULL DEFAULT '',
    first_triggered_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    last_triggered_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    acknowledged_at TIMESTAMPTZ,
    resolved_at TIMESTAMPTZ,
    trigger_count INTEGER NOT NULL DEFAULT 1,
    metadata JSONB NOT NULL DEFAULT '{}'::JSONB,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE UNIQUE INDEX IF NOT EXISTS uq_alerts_open_rule_entity
ON nexus.alerts(rule_id, entity_type, entity_id)
WHERE status IN ('open', 'acknowledged');

CREATE INDEX IF NOT EXISTS idx_alerts_status_severity
ON nexus.alerts(status, severity, last_triggered_at DESC);

CREATE INDEX IF NOT EXISTS idx_alerts_entity
ON nexus.alerts(entity_type, entity_id, last_triggered_at DESC);

CREATE TABLE IF NOT EXISTS nexus.alert_engine_state (
    engine_name TEXT PRIMARY KEY,
    last_event_id BIGINT NOT NULL DEFAULT 0,
    last_started_at TIMESTAMPTZ,
    last_completed_at TIMESTAMPTZ,
    last_status TEXT NOT NULL DEFAULT 'never-run',
    last_error TEXT NOT NULL DEFAULT '',
    evaluated_events INTEGER NOT NULL DEFAULT 0,
    alerts_opened INTEGER NOT NULL DEFAULT 0,
    alerts_updated INTEGER NOT NULL DEFAULT 0,
    alerts_resolved INTEGER NOT NULL DEFAULT 0,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

INSERT INTO nexus.alert_rules (
    rule_id, name, description, entity_type, event_type,
    minimum_severity, enabled, auto_resolve, cooldown_seconds
)
VALUES
(
    'resource-offline',
    'Resource Offline',
    'Open a critical alert when a persisted resource goes offline.',
    '*',
    'resource.offline',
    'critical',
    TRUE,
    TRUE,
    300
),
(
    'resource-degraded',
    'Resource Degraded',
    'Open a warning alert when a resource enters a degraded state.',
    '*',
    'resource.status_changed',
    'warning',
    TRUE,
    TRUE,
    300
),
(
    'endpoint-changed',
    'Endpoint Changed',
    'Track endpoint changes for persisted services.',
    '*',
    'resource.endpoint_changed',
    'warning',
    TRUE,
    FALSE,
    900
),
(
    'version-changed',
    'Version Changed',
    'Track software version changes.',
    '*',
    'resource.version_changed',
    'info',
    TRUE,
    FALSE,
    900
)
ON CONFLICT (rule_id) DO NOTHING;

INSERT INTO public.schema_migrations(version, description)
VALUES ('008', 'Platform alert rules, active alerts, and alert engine state')
ON CONFLICT (version) DO NOTHING;

COMMIT;
