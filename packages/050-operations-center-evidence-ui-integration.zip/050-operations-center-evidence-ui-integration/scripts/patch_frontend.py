from pathlib import Path
import re,shutil
P=Path(__file__).resolve().parents[1]; R=P.parents[1]; F=R/"frontend"
def backup(p):
 b=p.with_name(p.name+".before-package-050")
 if p.exists() and not b.exists(): shutil.copy2(p,b)
def patch_nav():
 p=F/"js/nav.js"; t=p.read_text()
 if "operations-center.html" in t:return
 backup(p)
 for pat in [r'(<a[^>]+href=["']/graph\.html["'][^>]*>.*?</a>)',r'(<a[^>]+href=["']/assets\.html["'][^>]*>.*?</a>)']:
  u,n=re.subn(pat,r'
<a href="/operations-center.html" data-nav="operations-center">Operations Center</a>',t,count=1,flags=re.I|re.S)
  if n:p.write_text(u);print("Operations Center navigation registered");return
 p.write_text(t+'
// PACKAGE-050-OPERATIONS-NAV
document.addEventListener("DOMContentLoaded",()=>{const n=document.querySelector("nav")||document.getElementById("nexusNav");if(n&&!n.querySelector('[href="/operations-center.html"]')){const a=document.createElement("a");a.href="/operations-center.html";a.textContent="Operations Center";n.appendChild(a)}});
')
def patch_home():
 p=F/"home-v2.html"
 if not p.exists():return
 t=p.read_text();backup(p)
 if "home-v2-evidence.css" not in t:t=t.replace("</head>",'  <link rel="stylesheet" href="/css/home-v2-evidence.css">
</head>',1)
 if "home-v2-evidence.js" not in t:t=t.replace("</body>",'  <script src="/js/evidence-client.js"></script>
  <script src="/js/home-v2-evidence.js"></script>
</body>',1)
 p.write_text(t);print("Home V2 evidence summary registered")
if not F.exists():raise SystemExit(f"Frontend not found: {F}")
patch_nav();patch_home()
