#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="${PROJECT_ROOT:-$HOME/Projects/Seymour/nexus-command-center}"
PKG="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
STAMP="$(date +%Y%m%d-%H%M%S)"
BACKUP="$ROOT/backend/data/private/package-backups/025-operations-center-ui-$STAMP"

cd "$ROOT"

mkdir -p "$BACKUP/frontend/js"
printf '%s\n' "$BACKUP" > "$PKG/.last_backup_dir"

cp frontend/js/nav.js \
  "$BACKUP/frontend/js/nav.js"

cp -r "$PKG/frontend/"* frontend/

sudo systemctl restart nexus-api.service
sleep 2

echo "Package 025 installed."
echo "Backup: $BACKUP"
