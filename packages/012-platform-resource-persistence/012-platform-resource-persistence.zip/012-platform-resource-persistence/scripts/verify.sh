#!/usr/bin/env bash
set -Eeuo pipefail
PROJECT_ROOT="${PROJECT_ROOT:-$HOME/Projects/Seymour/nexus-command-center}"
cd "$PROJECT_ROOT"
python3 -m backend.jobs.platform_resource_sync
set -a
source backend/data/private/cmdb.env
set +a
PGPASSWORD="$NEXUS_DB_PASSWORD" psql -h "$NEXUS_DB_HOST" -p "$NEXUS_DB_PORT" -U "$NEXUS_DB_USER" -d "$NEXUS_DB_NAME" -c "
SELECT COUNT(*) AS blockchain_nodes FROM nexus.blockchain_nodes;
SELECT COUNT(*) AS miningcore_instances FROM nexus.miningcore_instances;
SELECT instance_id,name,api_base_url,connected,api_online,status,health,pool_count
FROM nexus.miningcore_instances ORDER BY name;"
curl -fsS http://127.0.0.1:8080/api/platform/nodes | jq '{status,source,count}'
curl -fsS http://127.0.0.1:8080/api/platform/miningcore | jq '{status,source,count,connectedCount}'
python3 -m backend.jobs.platform_sync_job --stale-seconds 300 >/tmp/nexus-platform-sync-012.json
python3 - <<'PY2'
import json
p=json.load(open('/tmp/nexus-platform-sync-012.json'))
assert p['status']=='ok', p
assert p['resourcePersistence']['blockchain']['written'] >= 1, p
assert p['resourcePersistence']['miningcore']['written'] >= 2, p
print({'status':p['status'],'blockchain':p['resourcePersistence']['blockchain']['written'],'miningcore':p['resourcePersistence']['miningcore']['written']})
PY2
echo "Package 012 verified."
