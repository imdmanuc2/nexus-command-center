#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/../../.." && pwd)"; cd "$ROOT"; export PYTHONPATH="$ROOT"
set -a; source backend/data/private/cmdb.env; set +a
python3 - <<'PY'
from backend.playbooks.catalog import get_playbook_catalog
from backend.modules import platform_playbooks
items=get_playbook_catalog().list(); assert len(items)>=6
assert all(x['stepCount']>=2 for x in items)
assert platform_playbooks.catalog()['count']>=6
print('Playbook catalog PASS')
PY
for table in playbooks playbook_versions playbook_runs playbook_steps; do
  count=$(PGPASSWORD="$NEXUS_DB_PASSWORD" psql -At -h "$NEXUS_DB_HOST" -p "$NEXUS_DB_PORT" -U "$NEXUS_DB_USER" -d "$NEXUS_DB_NAME" -c "SELECT COUNT(*) FROM information_schema.tables WHERE table_schema='nexus' AND table_name='$table'")
  [[ "$count" == "1" ]] || { echo "$table FAIL"; exit 1; }; echo "$table PASS"
done
grep -q 'platform_playbooks' backend/api/server.py
grep -q '/api/playbooks/run' backend/api/server.py
grep -q 'Enterprise Playbooks' frontend/playbooks.html
echo "API routes PASS"; echo "Playbooks UI PASS"; echo "Package 030 verified."
