BEGIN;
CREATE TABLE IF NOT EXISTS nexus.playbooks (
  playbook_id TEXT PRIMARY KEY, name TEXT NOT NULL, description TEXT NOT NULL DEFAULT '',
  category TEXT NOT NULL DEFAULT 'operations', risk_level TEXT NOT NULL DEFAULT 'low',
  current_version TEXT NOT NULL, enabled BOOLEAN NOT NULL DEFAULT TRUE,
  source_path TEXT, created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(), updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE TABLE IF NOT EXISTS nexus.playbook_versions (
  playbook_id TEXT NOT NULL REFERENCES nexus.playbooks(playbook_id) ON DELETE CASCADE,
  version TEXT NOT NULL, definition JSONB NOT NULL, definition_hash TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(), PRIMARY KEY(playbook_id, version)
);
CREATE TABLE IF NOT EXISTS nexus.playbook_runs (
  run_id TEXT PRIMARY KEY, playbook_id TEXT NOT NULL REFERENCES nexus.playbooks(playbook_id),
  playbook_version TEXT NOT NULL, operation_session_id TEXT,
  target_asset_id TEXT, target_type TEXT, status TEXT NOT NULL,
  requested_by TEXT NOT NULL DEFAULT 'nexus-user', variables JSONB NOT NULL DEFAULT '{}'::jsonb,
  result JSONB NOT NULL DEFAULT '{}'::jsonb, error_message TEXT,
  started_at TIMESTAMPTZ, completed_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(), updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE TABLE IF NOT EXISTS nexus.playbook_steps (
  step_run_id BIGSERIAL PRIMARY KEY, run_id TEXT NOT NULL REFERENCES nexus.playbook_runs(run_id) ON DELETE CASCADE,
  step_id TEXT NOT NULL, position INTEGER NOT NULL, capability TEXT NOT NULL,
  status TEXT NOT NULL, parameters JSONB NOT NULL DEFAULT '{}'::jsonb,
  result JSONB NOT NULL DEFAULT '{}'::jsonb, error_message TEXT,
  started_at TIMESTAMPTZ, completed_at TIMESTAMPTZ,
  UNIQUE(run_id, step_id)
);
CREATE INDEX IF NOT EXISTS idx_playbook_runs_created ON nexus.playbook_runs(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_playbook_steps_run_position ON nexus.playbook_steps(run_id, position);
COMMIT;
