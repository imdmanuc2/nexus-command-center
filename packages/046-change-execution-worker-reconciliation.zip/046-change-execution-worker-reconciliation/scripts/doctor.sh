#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../../.." && pwd)"
PKG_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
test -f "$ROOT/backend/db/migrations/004_operations_queue.sql"
test -f "$ROOT/backend/capabilities/registry.py"
test -f "$ROOT/backend/transports/registry.py"
test -f "$ROOT/backend/data/private/cmdb.env"
command -v psql >/dev/null
command -v python3 >/dev/null
command -v curl >/dev/null
grep -q "FOR UPDATE SKIP LOCKED" "$PKG_DIR/backend/db/repositories/change_execution_repository.py"
python3 -m py_compile \
  "$PKG_DIR/backend/api/server.py" \
  "$PKG_DIR/backend/db/repositories/change_execution_repository.py" \
  "$PKG_DIR/backend/services/change_execution_service.py" \
  "$PKG_DIR/backend/jobs/change_execution_worker.py"
echo "Operations Queue integration: available"
echo "Managed Host capability registry: available"
echo "Package 046 doctor PASS"
