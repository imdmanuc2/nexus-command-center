BEGIN;

CREATE TABLE IF NOT EXISTS nexus.change_execution_workers (
    worker_id TEXT PRIMARY KEY,
    hostname TEXT NOT NULL,
    process_id INTEGER NOT NULL,
    status TEXT NOT NULL DEFAULT 'starting',
    current_operation_id TEXT,
    last_heartbeat_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    started_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    stopped_at TIMESTAMPTZ,
    metadata JSONB NOT NULL DEFAULT '{}'::JSONB
);

CREATE TABLE IF NOT EXISTS nexus.change_execution_attempts (
    attempt_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    change_id UUID REFERENCES nexus.change_requests(change_id) ON DELETE CASCADE,
    operation_id TEXT NOT NULL,
    worker_id TEXT NOT NULL,
    attempt_number INTEGER NOT NULL DEFAULT 1,
    status TEXT NOT NULL,
    capability TEXT NOT NULL,
    target_type TEXT NOT NULL,
    target_id TEXT NOT NULL,
    transport TEXT NOT NULL DEFAULT '',
    started_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    completed_at TIMESTAMPTZ,
    duration_ms INTEGER,
    exit_code INTEGER,
    timed_out BOOLEAN NOT NULL DEFAULT FALSE,
    stdout TEXT NOT NULL DEFAULT '',
    stderr TEXT NOT NULL DEFAULT '',
    result_data JSONB NOT NULL DEFAULT '{}'::JSONB,
    error_message TEXT NOT NULL DEFAULT ''
);

CREATE INDEX IF NOT EXISTS idx_change_execution_attempts_change
    ON nexus.change_execution_attempts(change_id, started_at DESC);
CREATE INDEX IF NOT EXISTS idx_change_execution_attempts_operation
    ON nexus.change_execution_attempts(operation_id, started_at DESC);
CREATE INDEX IF NOT EXISTS idx_change_execution_workers_heartbeat
    ON nexus.change_execution_workers(last_heartbeat_at DESC);

ALTER TABLE nexus.change_requests
    ADD COLUMN IF NOT EXISTS execution_worker_id TEXT;
ALTER TABLE nexus.change_requests
    ADD COLUMN IF NOT EXISTS verification_status TEXT NOT NULL DEFAULT '';
ALTER TABLE nexus.change_requests
    ADD COLUMN IF NOT EXISTS rollback_status TEXT NOT NULL DEFAULT '';

COMMIT;
