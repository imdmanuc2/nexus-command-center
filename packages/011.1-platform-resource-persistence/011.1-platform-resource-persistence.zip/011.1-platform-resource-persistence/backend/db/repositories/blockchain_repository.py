from psycopg.types.json import Jsonb
from backend.db.connection import get_connection, transaction

def upsert_blockchain_node(n):
    with transaction() as c:
        with c.cursor() as cur:
            cur.execute("""INSERT INTO nexus.blockchain_nodes(node_id,name,coin,chain,host,ip_address,rpc_port,p2p_port,rpc_connected,status,version,block_height,header_height,sync_percent,peer_count,mempool_transactions,disk_usage_bytes,first_seen_at,last_seen_at,last_changed_at,raw_payload,updated_at)
            VALUES(%(node_id)s,%(name)s,%(coin)s,%(chain)s,%(host)s,%(ip_address)s,%(rpc_port)s,%(p2p_port)s,%(rpc_connected)s,%(status)s,%(version)s,%(block_height)s,%(header_height)s,%(sync_percent)s,%(peer_count)s,%(mempool_transactions)s,%(disk_usage_bytes)s,NOW(),NOW(),NOW(),%(raw_payload)s,NOW())
            ON CONFLICT(node_id) DO UPDATE SET name=EXCLUDED.name,coin=EXCLUDED.coin,chain=EXCLUDED.chain,host=EXCLUDED.host,ip_address=EXCLUDED.ip_address,rpc_port=EXCLUDED.rpc_port,p2p_port=EXCLUDED.p2p_port,rpc_connected=EXCLUDED.rpc_connected,status=EXCLUDED.status,version=EXCLUDED.version,block_height=EXCLUDED.block_height,header_height=EXCLUDED.header_height,sync_percent=EXCLUDED.sync_percent,peer_count=EXCLUDED.peer_count,mempool_transactions=EXCLUDED.mempool_transactions,disk_usage_bytes=EXCLUDED.disk_usage_bytes,last_seen_at=NOW(),last_changed_at=CASE WHEN (nexus.blockchain_nodes.rpc_connected,nexus.blockchain_nodes.status,nexus.blockchain_nodes.version,nexus.blockchain_nodes.block_height) IS DISTINCT FROM (EXCLUDED.rpc_connected,EXCLUDED.status,EXCLUDED.version,EXCLUDED.block_height) THEN NOW() ELSE nexus.blockchain_nodes.last_changed_at END,raw_payload=EXCLUDED.raw_payload,updated_at=NOW() RETURNING *""",{**n,'raw_payload':Jsonb(n.get('raw_payload') or {})})
            return serialize(cur.fetchone())

def list_blockchain_nodes():
    with get_connection() as c:
        with c.cursor() as cur:
            cur.execute('SELECT * FROM nexus.blockchain_nodes ORDER BY name,node_id')
            return [serialize(r) for r in cur.fetchall()]

def mark_stale_blockchain_nodes(seconds=300):
    with transaction() as c:
        with c.cursor() as cur:
            cur.execute("UPDATE nexus.blockchain_nodes SET rpc_connected=FALSE,status='offline',updated_at=NOW() WHERE last_seen_at < NOW()-(%s*INTERVAL '1 second') AND status<>'offline'",(seconds,))
            return cur.rowcount

def serialize(r):
    return {'nodeId':r['node_id'],'name':r['name'],'coin':r['coin'],'chain':r['chain'],'host':r['host'],'ip':r['ip_address'],'rpcPort':r['rpc_port'],'p2pPort':r['p2p_port'],'rpcConnected':r['rpc_connected'],'status':r['status'],'version':r['version'],'blockHeight':r['block_height'],'headers':r['header_height'],'syncPercent':r['sync_percent'],'peers':r['peer_count'],'mempoolTransactions':r['mempool_transactions'],'diskUsageBytes':r['disk_usage_bytes'],'firstSeenAt':r['first_seen_at'].isoformat() if r['first_seen_at'] else None,'lastSeenAt':r['last_seen_at'].isoformat() if r['last_seen_at'] else None,'lastChangedAt':r['last_changed_at'].isoformat() if r['last_changed_at'] else None,'raw':r['raw_payload'] or {}}
