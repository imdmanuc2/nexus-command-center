from backend.db.repositories.blockchain_repository import upsert_blockchain_node,mark_stale_blockchain_nodes
from backend.services.resource_sync_common import fetch_json,stable_id

def candidates(payload):
    if isinstance(payload,list):return [x for x in payload if isinstance(x,dict)]
    if not isinstance(payload,dict):return []
    for k in ('nodes','items','assets','data'):
        if isinstance(payload.get(k),list):return [x for x in payload[k] if isinstance(x,dict)]
    if any(k in payload for k in ('rpcConnected','blockHeight','blocks','headers','ip','name','coin')):return [payload]
    for v in payload.values():
        if isinstance(v,dict) and any(k in v for k in ('rpcConnected','blockHeight','blocks','headers')):return [v]
    return []
def pct(v):
    try:x=float(v);return x*100 if 0<=x<=1 else x
    except:return None

def synchronize_blockchain_nodes(stale_seconds=300):
    payload=fetch_json('/api/blockchain/nodes'); rows=[]
    for raw in candidates(payload):
        name=str(raw.get('name') or raw.get('friendlyName') or raw.get('displayName') or 'Blockchain Node'); ip=str(raw.get('ip') or raw.get('host') or ''); coin=str(raw.get('coin') or raw.get('symbol') or 'BTC').upper(); chain=str(raw.get('chain') or raw.get('network') or 'main'); connected=bool(raw.get('rpcConnected') or str(raw.get('rpcStatus') or '').lower() in {'online','connected','healthy'})
        rows.append(upsert_blockchain_node({'node_id':str(raw.get('nodeId') or raw.get('id') or raw.get('assetId') or stable_id('blockchain-node',coin,ip,name)),'name':name,'coin':coin,'chain':chain,'host':str(raw.get('host') or ip),'ip_address':ip,'rpc_port':raw.get('rpcPort') or 8332,'p2p_port':raw.get('p2pPort') or 8333,'rpc_connected':connected,'status':str(raw.get('status') or ('online' if connected else 'offline')),'version':str(raw.get('version') or raw.get('subversion') or ''),'block_height':raw.get('blockHeight') or raw.get('blocks'),'header_height':raw.get('headerHeight') or raw.get('headers'),'sync_percent':pct(raw.get('syncPercent') or raw.get('verificationProgress')),'peer_count':raw.get('peerCount') or raw.get('peers'),'mempool_transactions':raw.get('mempoolTransactions') or raw.get('mempoolTx'),'disk_usage_bytes':raw.get('diskUsageBytes') or raw.get('diskUsage'),'raw_payload':raw}))
    return {'status':'ok','observed':len(rows),'written':len(rows),'markedOffline':mark_stale_blockchain_nodes(stale_seconds),'nodes':rows}
