import json
from pathlib import Path

from backend.core.assets import get_assets_list
from backend.modules import discovery
from backend.modules import mining


def pool_node_id(pool):
    return (
        f"pool-{pool.get('id', 'unknown')}-"
        f"{str(pool.get('host', 'unknown')).replace('.', '-')}"
    )


def host_node_id(host):
    return f"host-{str(host).replace('.', '-')}"


def worker_node_id(worker):
    value = (
        worker.get("workerName")
        or worker.get("name")
        or worker.get("workerId")
        or "unknown"
    )

    return f"worker-{value}"


def add_node(nodes, node):
    nodes[node["id"]] = node


def add_edge(edges, source, target, rel_type, label=None):
    if not source or not target:
        return

    edge = {
        "source": source,
        "target": target,
        "type": rel_type,
        "label": label or rel_type.replace("_", " ").title(),
    }

    if edge not in edges:
        edges.append(edge)


def load_external_graphs():
    graph_dir = Path("backend/data/external_graphs")
    graphs = []

    if not graph_dir.exists():
        return graphs

    for path in graph_dir.glob("*.json"):
        try:
            graphs.append(json.loads(path.read_text()))
        except Exception:
            pass

    return graphs


def merge_external_graphs(nodes, edges):
    for graph in load_external_graphs():
        source = graph.get("source", "external")

        for node in graph.get("nodes", []):
            node_id = f"{source}:{node.get('id')}"

            nodes[node_id] = {
                "id": node_id,
                "type": node.get("type", "external"),
                "label": node.get("label", node.get("id")),
                "status": "online",
                "properties": {
                    **node.get("metadata", {}),
                    "source": source,
                    "externalId": node.get("id"),
                },
            }

        for edge in graph.get("edges", []):
            edges.append({
                "source": f"{source}:{edge.get('source')}",
                "target": f"{source}:{edge.get('target')}",
                "type": edge.get("type", "RELATED_TO"),
                "label": (
                    edge.get("type", "RELATED_TO")
                    .replace("_", " ")
                    .title()
                ),
            })


def _managed_assets():
    return [
        asset
        for asset in get_assets_list()
        if asset.get("managed") is True
        and asset.get("lifecycleStatus") == "managed"
    ]


def _asset_by_ip(assets):
    return {
        str(asset.get("ip")): asset
        for asset in assets
        if asset.get("ip")
    }


def _pool_hosts(pools):
    return {
        str(pool.get("host"))
        for pool in pools
        if pool.get("host")
    }


def _system_by_ip(systems):
    return {
        str(system.get("ip")): system
        for system in systems
        if system.get("ip")
    }


def _host_properties(system, managed_asset=None):
    system = system or {}
    managed_asset = managed_asset or {}

    return {
        "ip": system.get("ip") or managed_asset.get("ip"),
        "primaryRole": (
            managed_asset.get("primaryRole")
            or system.get("primaryRole")
        ),
        "openPorts": (
            managed_asset.get("openPorts")
            or system.get("openPorts", [])
        ),
        "services": (
            managed_asset.get("services")
            or system.get("services", [])
        ),
        "health": system.get("health", {}),
        "profile": system.get("profile", {}),
        "managed": bool(managed_asset),
        "lifecycleStatus": (
            managed_asset.get("lifecycleStatus")
            if managed_asset
            else "discovered"
        ),
        "assetType": (
            managed_asset.get("assetType")
            or managed_asset.get("type")
            or "server"
        ),
        "friendlyName": managed_asset.get("friendlyName"),
        "addedAt": managed_asset.get("addedAt"),
    }


def build_graph():
    topo_payload = discovery.topology()
    topo = topo_payload.get("topology", {})
    discovery_data = topo_payload.get("discovery", {})

    assets = _managed_assets()
    assets_by_ip = _asset_by_ip(assets)

    try:
        mining_data = mining.workers()
        workers = mining_data.get("workers", [])
    except Exception:
        workers = []

    pools = topo.get("pools", [])
    systems = discovery_data.get("systems", [])
    systems_by_ip = _system_by_ip(systems)
    pool_hosts = _pool_hosts(pools)

    nodes = {}
    edges = []

    # Internal host nodes are only created when:
    # 1. the operator manages the system, or
    # 2. a live pool needs the host for a graph relationship.
    candidate_host_ips = set(assets_by_ip) | pool_hosts

    for ip in sorted(candidate_host_ips):
        system = systems_by_ip.get(ip, {"ip": ip})
        managed_asset = assets_by_ip.get(ip)

        label = (
            managed_asset.get("friendlyName")
            if managed_asset
            else None
        ) or (
            managed_asset.get("name")
            if managed_asset
            else None
        ) or (
            system.get("asset", {}).get("friendlyName")
            or system.get("asset", {}).get("name")
            or ip
        )

        # Host nodes exist only to support internal graph relationships.
        # They must never impersonate the managed ASIC, blockchain node,
        # or other asset using the same IP address.
        add_node(nodes, {
            "id": host_node_id(ip),
            "type": "host",
            "label": label,
            "status": (
                system.get("health", {}).get("level")
                or "online"
            ),
            "properties": {
                **_host_properties(
                    system,
                    managed_asset,
                ),
                "internalGraphNode": True,
                "managedAssetId": (
                    managed_asset.get("id")
                    if managed_asset
                    else None
                ),
            },
        })

    # Logical mining pool nodes.
    for pool in pools:
        pid = pool_node_id(pool)
        host = str(pool.get("host") or "")
        host_id = host_node_id(host)

        add_node(nodes, {
            "id": pid,
            "type": "pool",
            "label": pool.get("name") or pool.get("id"),
            "status": "online",
            "properties": {
                **pool,
                "assetType": "pool",
                "managed": True,
                "lifecycleStatus": "managed",
            },
        })

        if host:
            add_edge(
                edges,
                pid,
                host_id,
                "HOSTED_ON",
            )

    # Managed infrastructure assets.
    #
    # Live MiningCore worker telemetry is authoritative for current pool
    # routing. Saved poolId/poolHost values are only a fallback when a miner
    # is not currently visible in the worker API.
    def worker_suffix(value):
        raw = str(value or "").strip()

        if not raw:
            return ""

        return raw.rsplit(".", 1)[-1].lower().lstrip("0") or "0"

    def live_worker_for_asset(asset):
        asset_worker = worker_suffix(asset.get("workerId"))
        asset_name = str(
            asset.get("friendlyName")
            or asset.get("name")
            or ""
        ).strip().lower()

        asset_ip = str(asset.get("ip") or "").strip()

        for worker in workers:
            worker_name = worker_suffix(
                worker.get("workerName")
                or worker.get("name")
                or worker.get("workerId")
            )

            worker_asset_name = str(
                worker.get("assetName")
                or worker.get("displayName")
                or ""
            ).strip().lower()

            worker_asset_ip = str(
                worker.get("assetIp")
                or ""
            ).strip()

            if asset_worker and worker_name == asset_worker:
                return worker

            if asset_name and worker_asset_name == asset_name:
                return worker

            if asset_ip and worker_asset_ip == asset_ip:
                return worker

        return None

    for asset in assets:
        aid = asset.get("id")
        ip = str(asset.get("ip") or "")
        live_worker = live_worker_for_asset(asset)

        runtime_properties = {
            **asset,
            "managed": True,
            "lifecycleStatus": "managed",
        }

        if live_worker:
            runtime_properties.update({
                "liveWorkerId": (
                    live_worker.get("workerName")
                    or live_worker.get("name")
                    or live_worker.get("workerId")
                ),
                "livePoolId": live_worker.get("poolId"),
                "livePoolHost": (
                    live_worker.get("poolHost")
                    or live_worker.get("host")
                ),
                "liveHashrate": float(
                    live_worker.get("hashrate")
                    or live_worker.get("hashRate")
                    or 0
                ),
                "liveSharesPerSecond": float(
                    live_worker.get("sharesPerSecond")
                    or live_worker.get("shares_per_second")
                    or 0
                ),
                "liveMining": float(
                    live_worker.get("hashrate")
                    or live_worker.get("hashRate")
                    or 0
                ) > 0,
            })

        add_node(nodes, {
            "id": aid,
            "type": (
                asset.get("assetType")
                or asset.get("type")
                or "unknown"
            ),
            "label": (
                asset.get("friendlyName")
                or asset.get("name")
                or ip
            ),
            "status": (
                "online"
                if live_worker and runtime_properties["liveMining"]
                else "idle"
                if asset.get("assetType") == "asic"
                else "online"
            ),
            "properties": runtime_properties,
        })

        if ip:
            add_edge(
                edges,
                aid,
                host_node_id(ip),
                "HAS_NETWORK_IDENTITY",
            )

        # Current MiningCore worker routing wins.
        effective_pool_id = (
            live_worker.get("poolId")
            if live_worker
            else asset.get("poolId")
        )

        effective_pool_host = (
            (
                live_worker.get("poolHost")
                or live_worker.get("host")
            )
            if live_worker
            else asset.get("poolHost")
        )

        if effective_pool_id and effective_pool_host:
            requested_pool_id = str(
                effective_pool_id or ""
            ).lower()

            requested_pool_host = str(
                effective_pool_host or ""
            )

            def pool_matches_live_worker(pool):
                pool_id = str(
                    pool.get("id") or ""
                ).lower()

                pool_host = str(
                    pool.get("host") or ""
                )

                canonical_graph_id = pool_node_id(pool).lower()

                # MiningCore discovery may return IDs such as:
                # pool-192-168-1-156-4000-bch
                canonical_worker_suffix = (
                    requested_pool_id.rsplit("-", 1)[-1]
                )

                id_matches = (
                    requested_pool_id == pool_id
                    or requested_pool_id == canonical_graph_id
                    or requested_pool_id.endswith(f"-{pool_id}")
                    or canonical_worker_suffix == pool_id
                )

                return (
                    id_matches
                    and pool_host == requested_pool_host
                )

            matching_pool = next(
                (
                    pool
                    for pool in pools
                    if pool_matches_live_worker(pool)
                ),
                None,
            )

            if matching_pool:
                add_edge(
                    edges,
                    aid,
                    pool_node_id(matching_pool),
                    "MINES_ON",
                )

    # Worker nodes remain in the relationship graph, but the frontend
    # Inventory intentionally treats them as ASIC metadata.
    for worker in workers:
        wid = worker_node_id(worker)

        add_node(nodes, {
            "id": wid,
            "type": "worker",
            "label": (
                worker.get("displayName")
                or worker.get("workerName")
                or worker.get("name")
            ),
            "status": "online",
            "properties": worker,
        })

        worker_name = str(
            worker.get("workerName")
            or worker.get("name")
            or ""
        )

        asset = next(
            (
                item
                for item in assets
                if str(item.get("workerId", "")).zfill(3)
                == worker_name.zfill(3)
            ),
            None,
        )

        if asset:
            add_edge(
                edges,
                asset.get("id"),
                wid,
                "RUNS_WORKER",
            )

        matching_pool = next(
            (
                pool
                for pool in pools
                if pool.get("id") == worker.get("poolId")
                and pool.get("host")
                == (
                    worker.get("poolHost")
                    or worker.get("host")
                )
            ),
            None,
        )

        if matching_pool:
            add_edge(
                edges,
                wid,
                pool_node_id(matching_pool),
                "MINES_ON",
            )

    merge_external_graphs(nodes, edges)

    return {
        "nodes": list(nodes.values()),
        "edges": edges,
        "counts": {
            "nodes": len(nodes),
            "edges": len(edges),
            "assets": len(assets),
            "pools": len(pools),
            "workers": len(workers),
            "hosts": len(candidate_host_ips),
        },
    }


def relationships_for(node_id):
    graph = build_graph()

    edges = [
        edge
        for edge in graph["edges"]
        if edge["source"] == node_id
        or edge["target"] == node_id
    ]

    return {
        "nodeId": node_id,
        "relationships": edges,
        "graph": graph,
    }
