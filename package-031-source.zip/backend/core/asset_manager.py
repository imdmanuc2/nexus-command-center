"""Nexus canonical infrastructure asset manager.

This module is the single source of truth for managed infrastructure assets.

Discovery results are staging records. They are not persisted here until the
operator explicitly chooses Add to Infrastructure.
"""

from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
from uuid import uuid4

from backend.core.asset_classifier import classify_asset
from backend.core.cmdb_audit import append_event
from backend.db.repositories import asset_repository
from backend.db.repositories.asset_repository_extensions import find_by_ip


ASSETS_DB = Path("backend/data/assets.json")


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def _string(value: Any) -> str:
    if value is None:
        return ""
    return str(value).strip()


def _normalize_ports(value: Any) -> list[int]:
    ports: set[int] = set()

    def visit(item: Any) -> None:
        if item is None:
            return

        if isinstance(item, dict):
            if "port" in item:
                try:
                    ports.add(int(item["port"]))
                except (TypeError, ValueError):
                    pass

            for nested in item.values():
                visit(nested)
            return

        if isinstance(item, (list, tuple, set)):
            for nested in item:
                visit(nested)
            return

        try:
            ports.add(int(item))
        except (TypeError, ValueError):
            pass

    visit(value)
    return sorted(ports)


def _normalize_services(value: Any) -> list[dict[str, Any]]:
    if not isinstance(value, list):
        return []

    services: list[dict[str, Any]] = []
    seen: set[tuple[str, int]] = set()

    for item in value:
        if isinstance(item, dict):
            name = (
                item.get("name")
                or item.get("service")
                or item.get("label")
                or "Unknown Service"
            )

            try:
                port = int(item.get("port") or 0)
            except (TypeError, ValueError):
                port = 0

            service = {
                **item,
                "name": str(name),
                "port": port,
            }
        else:
            service = {
                "name": str(item),
                "port": 0,
            }

        key = (service["name"].lower(), service["port"])

        if key not in seen:
            seen.add(key)
            services.append(service)

    return services


def _display_name(asset: dict[str, Any], ip: str) -> str:
    candidates = [
        asset.get("friendlyName"),
        asset.get("displayName"),
        asset.get("name"),
        asset.get("primaryRole"),
        asset.get("hostname"),
        ip,
    ]

    for candidate in candidates:
        value = _string(candidate)
        if value:
            return value

    return ip


def _asset_quality(asset: dict[str, Any]) -> int:
    """Higher score means a record is more authoritative."""

    score = 0

    name = _display_name(asset, _string(asset.get("ip"))).lower()
    asset_type = _string(
        asset.get("assetType")
        or asset.get("canonicalType")
        or asset.get("type")
    ).lower()

    if asset.get("managed") is True:
        score += 100

    if asset.get("lifecycleStatus") == "managed":
        score += 80

    if asset.get("createdAutomatically") is False:
        score += 50

    if asset_type not in {"", "unknown", "infrastructure-node", "host"}:
        score += 40

    if name and "unknown" not in name:
        score += 30

    if name in {
        "bitcoin core",
        "bitcoin cash node",
        "nano 3s",
        "mining system 2",
    }:
        score += 20

    if asset.get("friendlyName"):
        score += 10

    return score


def normalize_asset(
    asset: dict[str, Any],
    *,
    default_ip: str | None = None,
) -> dict[str, Any]:
    item = dict(asset or {})

    ip = _string(item.get("ip") or default_ip)

    if not ip:
        raise ValueError("Infrastructure asset requires an IP address.")

    services = _normalize_services(item.get("services"))
    open_ports = _normalize_ports(
        [
            item.get("openPorts"),
            item.get("open_ports"),
            item.get("ports"),
            services,
        ]
    )

    canonical_type = classify_asset(
        object_type=item.get("type"),
        asset_type=(
            item.get("assetType")
            or item.get("canonicalType")
            or item.get("canonical_type")
        ),
        node_id=item.get("id"),
        name=_display_name(item, ip),
        primary_role=(
            item.get("primaryRole")
            or item.get("primary_role")
            or item.get("purpose")
        ),
        open_ports=open_ports,
        services=services,
        properties=item,
    )

    name = _display_name(item, ip)
    created_at = item.get("createdAt") or now_iso()

    normalized = {
        **item,
        "id": item.get("id") or f"asset-{uuid4().hex[:8]}",
        "ip": ip,
        "name": name,
        "friendlyName": name,
        "displayName": item.get("displayName") or name,
        "type": canonical_type,
        "assetType": canonical_type,
        "canonicalType": canonical_type,
        "purpose": item.get("purpose") or _default_purpose(canonical_type),
        "coin": item.get("coin"),
        "primaryRole": item.get("primaryRole") or item.get("primary_role"),
        "openPorts": open_ports,
        "services": services,
        "managed": bool(item.get("managed", not item.get("createdAutomatically", False))),
        "lifecycleStatus": item.get("lifecycleStatus")
        or (
            "managed"
            if bool(item.get("managed", not item.get("createdAutomatically", False)))
            else "discovered"
        ),
        "createdAutomatically": bool(item.get("createdAutomatically", False)),
        "createdAt": created_at,
        "updatedAt": item.get("updatedAt") or now_iso(),
        "favorite": bool(item.get("favorite", False)),
        "notes": item.get("notes") or "",
        "tags": item.get("tags") or [],
        "location": item.get("location") or "",
        "rack": item.get("rack") or "",
        "position": item.get("position") or "",
        "manufacturer": item.get("manufacturer") or "",
        "model": item.get("model") or "",
        "serialNumber": item.get("serialNumber") or "",
        "macAddress": item.get("macAddress") or "",
        "hostname": item.get("hostname") or "",
        "workerId": item.get("workerId") or "",
        "poolId": item.get("poolId") or "",
        "poolHost": item.get("poolHost") or "",
        "poolGroup": item.get("poolGroup") or "",

        # Compute inventory
        "computeProfile": (
            item.get("computeProfile")
            if isinstance(item.get("computeProfile"), dict)
            else {}
        ),
        "components": (
            item.get("components")
            if isinstance(item.get("components"), list)
            else []
        ),
        "capabilities": sorted({
            str(value).strip()
            for value in (item.get("capabilities") or [])
            if str(value).strip()
        }),
        "allocation": (
            item.get("allocation")
            if isinstance(item.get("allocation"), dict)
            else {
                "state": "unallocated",
                "activeWorkloadType": "",
                "activeWorkloadId": "",
            }
        ),
        "workloads": (
            item.get("workloads")
            if isinstance(item.get("workloads"), list)
            else []
        ),

        # Runtime and virtualization identity
        "operatingSystem": item.get("operatingSystem") or "",
        "architecture": item.get("architecture") or "",
        "hypervisor": item.get("hypervisor") or "",
        "containerRuntime": item.get("containerRuntime") or "",

        # Financial and operational intent
        "criticality": item.get("criticality") or "normal",
        "owner": item.get("owner") or "",
        "businessService": item.get("businessService") or "",
    }

    return normalized


def _default_purpose(asset_type: str) -> str:
    return {
        "asic": "Dedicated Mining",
        "pool": "Mining Pool",
        "compute-host": "Compute",
        "cpu-device": "Compute Component",
        "gpu-device": "Compute Accelerator",
        "virtual-machine": "Virtual Compute",
        "container": "Container Workload",
        "workload": "Workload",
        "blockchain-node": "Blockchain",
        "server": "Infrastructure",
        "unknown": "Unknown",
    }.get(asset_type, "Infrastructure")


def _raw_asset_list(raw: Any) -> list[dict[str, Any]]:
    if isinstance(raw, list):
        return [item for item in raw if isinstance(item, dict)]

    if isinstance(raw, dict):
        if isinstance(raw.get("assets"), list):
            return [
                item
                for item in raw["assets"]
                if isinstance(item, dict)
            ]

        result: list[dict[str, Any]] = []

        for ip, item in raw.items():
            if isinstance(item, dict):
                result.append({
                    **item,
                    "ip": item.get("ip") or ip,
                })

        return result

    return []


def asset_identity(asset: dict[str, Any]) -> str:
    """Return the canonical identity for one managed object.

    Multiple logical or physical objects may share an IP address. For
    example, a mining host, an ASIC identity, and a pool can all be
    associated with the same address. They must not be merged by IP alone.
    """

    ip = _string(asset.get("ip"))
    asset_type = _string(
        asset.get("assetType")
        or asset.get("canonicalType")
        or asset.get("type")
        or "unknown"
    ).lower()

    asset_id = _string(asset.get("id"))
    worker_id = _string(asset.get("workerId"))
    pool_id = _string(asset.get("poolId"))
    pool_host = _string(asset.get("poolHost"))
    name = _display_name(asset, ip).lower()

    if asset_type == "asic":
        if worker_id:
            return f"asic:{ip}:{worker_id.zfill(3)}"
        if asset_id:
            return f"asic-id:{asset_id}"
        return f"asic:{ip}:{name}"

    if asset_type == "pool":
        return f"pool:{pool_id or name}:{pool_host or ip}"

    if asset_type == "blockchain-node":
        coin = _string(asset.get("coin")).upper() or "UNKNOWN"
        return f"blockchain-node:{coin}:{ip}"

    if asset_type == "gpu-device":
        gpu_uuid = _string(
            asset.get("gpuUuid")
            or asset.get("uuid")
            or asset.get("serialNumber")
        )

        if gpu_uuid:
            return f"gpu-device:{gpu_uuid.lower()}"

        pci_address = _string(asset.get("pciAddress"))

        if pci_address:
            return f"gpu-device:{ip}:{pci_address.lower()}"

    if asset_type == "cpu-device":
        component_id = _string(
            asset.get("componentId")
            or asset.get("serialNumber")
            or asset.get("model")
        )

        if component_id:
            return f"cpu-device:{ip}:{component_id.lower()}"

    if asset_type == "virtual-machine":
        machine_uuid = _string(
            asset.get("machineUuid")
            or asset.get("vmUuid")
            or asset.get("uuid")
        )

        if machine_uuid:
            return f"virtual-machine:{machine_uuid.lower()}"

    if asset_type == "container":
        container_id = _string(
            asset.get("containerId")
            or asset.get("runtimeId")
        )

        if container_id:
            return f"container:{container_id.lower()}"

    if asset_type == "workload":
        workload_id = _string(
            asset.get("workloadId")
            or asset.get("id")
        )

        if workload_id:
            return f"workload:{workload_id.lower()}"

    if asset_type in {"compute-host", "server"}:
        host_uuid = _string(
            asset.get("machineUuid")
            or asset.get("systemUuid")
            or asset.get("serialNumber")
            or asset.get("macAddress")
        )

        if host_uuid:
            return f"{asset_type}:{host_uuid.lower()}"

        return f"{asset_type}:{ip}"

    if asset_id:
        return f"{asset_type}:id:{asset_id}"

    return f"{asset_type}:{ip}:{name}"


def _merge_assets(
    first: dict[str, Any],
    second: dict[str, Any],
) -> dict[str, Any]:
    """Merge records only when they represent the same asset identity."""

    if _asset_quality(second) > _asset_quality(first):
        preferred = dict(second)
        fallback = first
    else:
        preferred = dict(first)
        fallback = second

    for key, value in fallback.items():
        current = preferred.get(key)

        if current in (None, "", [], {}):
            preferred[key] = value

    preferred["services"] = _normalize_services(
        list(first.get("services") or [])
        + list(second.get("services") or [])
    )

    preferred["openPorts"] = _normalize_ports(
        [
            first.get("openPorts"),
            second.get("openPorts"),
            preferred["services"],
        ]
    )

    preferred["updatedAt"] = now_iso()

    return normalize_asset(
        preferred,
        default_ip=preferred.get("ip"),
    )


def load_assets() -> list[dict[str, Any]]:
    if not ASSETS_DB.exists():
        return []

    try:
        raw = json.loads(ASSETS_DB.read_text() or "[]")
    except (json.JSONDecodeError, OSError):
        return []

    grouped: dict[str, dict[str, Any]] = {}

    for raw_asset in _raw_asset_list(raw):
        try:
            asset = normalize_asset(
                raw_asset,
                default_ip=raw_asset.get("ip"),
            )
        except ValueError:
            continue

        identity = asset_identity(asset)

        if identity in grouped:
            grouped[identity] = _merge_assets(
                grouped[identity],
                asset,
            )
        else:
            grouped[identity] = asset

    return sorted(
        grouped.values(),
        key=lambda item: (
            item.get("assetType") or "unknown",
            item.get("friendlyName") or item.get("ip"),
        ),
    )


def save_assets(assets: list[dict[str, Any]]) -> None:
    """Persist normalized assets to PostgreSQL.

    This compatibility function intentionally does not delete database rows
    missing from the supplied list. Deletion must be an explicit CMDB action.
    """
    for asset in assets:
        asset_repository.upsert_asset(normalize_asset(asset))



def migrate_assets() -> list[dict[str, Any]]:
    """Return canonical assets from PostgreSQL.

    The historical function name is retained for connector compatibility.
    No runtime JSON migration or rewrite occurs here.
    """
    return asset_repository.list_assets(limit=5000)



def get_assets_list() -> list[dict[str, Any]]:
    """Return all canonical CMDB assets from PostgreSQL."""
    return asset_repository.list_assets(limit=5000)



def get_assets_by_ip(ip: str) -> list[dict[str, Any]]:
    target = _string(ip)

    return [
        asset
        for asset in get_assets_list()
        if asset.get("ip") == target
    ]


def get_asset(
    ip: str,
    *,
    asset_type: str | None = None,
) -> dict[str, Any] | None:
    candidates = get_assets_by_ip(ip)

    if asset_type:
        canonical = _string(asset_type).lower()

        candidates = [
            asset
            for asset in candidates
            if _string(
                asset.get("assetType")
                or asset.get("type")
            ).lower() == canonical
        ]

    if not candidates:
        return None

    return max(candidates, key=_asset_quality)


def discovery_asset(system: dict[str, Any]) -> dict[str, Any]:
    """Return an existing managed asset or an ephemeral staging record.

    New scan results are deliberately not saved here.
    """

    ip = _string(system.get("ip"))

    requested_type = classify_asset(
        object_type=system.get("type"),
        asset_type=system.get("assetType"),
        name=system.get("primaryRole") or ip,
        primary_role=system.get("primaryRole"),
        open_ports=system.get("openPorts"),
        services=system.get("services"),
        properties=system,
    )

    existing = get_asset(
        ip,
        asset_type=requested_type,
    )

    if existing:
        return existing

    role = _string(system.get("primaryRole"))

    asset_type = requested_type

    name = role if role and "unknown" not in role.lower() else ip

    return normalize_asset({
        "id": f"discovered-{ip.replace('.', '-')}",
        "ip": ip,
        "name": name,
        "friendlyName": name,
        "type": asset_type,
        "assetType": asset_type,
        "primaryRole": role,
        "openPorts": system.get("openPorts", []),
        "services": system.get("services", []),
        "managed": False,
        "lifecycleStatus": "discovered",
        "createdAutomatically": True,
    })


def upsert_managed_asset(
    system: dict[str, Any],
) -> dict[str, Any]:
    """Normalize, reconcile, audit, and persist one managed CMDB asset."""
    if not isinstance(system, dict):
        raise ValueError("Managed asset payload must be an object.")

    audit_context = {
        "actor_type": system.get("_actorType", "system"),
        "actor_id": system.get("_actorId", "nexus"),
        "source": system.get("_source", "asset-manager"),
        "reason": system.get("_reason", ""),
        "correlation_id": system.get("_correlationId"),
        "confidence": system.get("_confidence"),
    }

    clean = {
        key: value
        for key, value in system.items()
        if key not in {
            "_actorType", "_actorId", "_source", "_reason",
            "_correlationId", "_confidence",
        }
    }

    incoming = normalize_asset(clean)
    assets = asset_repository.list_assets(limit=5000)
    incoming_identity = asset_identity(incoming)

    existing = next(
        (asset for asset in assets if asset.get("id") == incoming.get("id")),
        None,
    )

    if existing is None:
        existing = next(
            (
                asset
                for asset in assets
                if asset_identity(asset) == incoming_identity
            ),
            None,
        )

    if existing is None and incoming.get("ip"):
        same_ip = find_by_ip(incoming["ip"])
        same_type = [
            asset
            for asset in same_ip
            if asset.get("assetType") == incoming.get("assetType")
        ]
        if same_type:
            existing = max(same_type, key=_asset_quality)

    before = dict(existing) if existing else None
    merged = {
        **(existing or {}),
        **incoming,
        "id": (existing or {}).get("id") or incoming.get("id"),
        "createdAt": (existing or {}).get("createdAt") or incoming.get("createdAt"),
        "updatedAt": now_iso(),
    }

    managed_asset = normalize_asset(merged)
    persisted = asset_repository.upsert_asset(managed_asset)

    append_event(
        action="asset.updated" if existing else "asset.created",
        asset_id=persisted.get("id"),
        asset_type=persisted.get("assetType"),
        asset_name=(
            persisted.get("friendlyName")
            or persisted.get("name")
            or persisted.get("ip")
        ),
        actor_type=audit_context["actor_type"],
        actor_id=audit_context["actor_id"],
        source=audit_context["source"],
        reason=audit_context["reason"],
        correlation_id=audit_context["correlation_id"],
        confidence=audit_context["confidence"],
        before=before,
        after=persisted,
        metadata={
            "ip": persisted.get("ip"),
            "workerId": persisted.get("workerId"),
            "poolId": persisted.get("poolId"),
            "storage": "postgresql",
        },
    )

    return persisted



def update_asset(
    ip: str,
    updates: dict[str, Any],
) -> dict[str, Any]:
    """Update the highest-quality CMDB asset currently using an IP address."""
    matches = find_by_ip(ip)
    if not matches:
        raise KeyError(f"No managed asset found for IP {ip}")

    existing = max(matches, key=_asset_quality)
    payload = {
        **existing,
        **dict(updates or {}),
        "id": existing.get("id"),
        "ip": existing.get("ip") or ip,
        "createdAt": existing.get("createdAt"),
        "_actorType": (updates or {}).get("_actorType", "user"),
        "_actorId": (updates or {}).get("_actorId", "operator"),
        "_source": (updates or {}).get("_source", "assets-api"),
        "_reason": (updates or {}).get("_reason", "Update CMDB asset"),
        "_correlationId": (updates or {}).get("_correlationId"),
        "_confidence": (updates or {}).get("_confidence"),
    }
    return upsert_managed_asset(payload)

